# Snpnet - Efficient Lasso Solver for Large-scale SNP Data

License: GPL-2

### Reference: 
  - Qian, Junyang, Wenfei Du, Yosuke Tanigawa, Matthew Aguirre, Robert Tibshirani, Manuel A. Rivas, and Trevor Hastie. "A Fast and Flexible Algorithm for Solving the Lasso in Large-scale and Ultrahigh-dimensional Problems." bioRxiv (2019): https://www.biorxiv.org/content/10.1101/630079v1
